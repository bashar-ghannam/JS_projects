# Resume-CV-Design-N19
How to create the Resume/CV Design using HTML and CSS
